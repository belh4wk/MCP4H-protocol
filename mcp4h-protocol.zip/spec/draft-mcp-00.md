# MCP: Multimodal Communication Protocol
See root-level draft for full context.
(This file will track working group edits once repo is live.)
